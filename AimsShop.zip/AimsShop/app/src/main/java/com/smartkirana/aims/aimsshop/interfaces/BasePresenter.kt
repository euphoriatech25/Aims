package com.smartkirana.aims.aimsshop.interfaces

interface BasePresenter {
    fun onDestroy()
}