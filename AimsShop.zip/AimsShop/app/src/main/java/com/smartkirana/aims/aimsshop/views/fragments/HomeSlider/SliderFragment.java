package com.smartkirana.aims.aimsshop.views.fragments.HomeSlider;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;

import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SliderFragment extends Fragment {

    public SliderLayout mDemoSlider;
    public SliderModel slider;


    HashMap<String, String> url_maps;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_slider, parent, false);

        mDemoSlider = view.findViewById(R.id.slider);
        getSliderDetails();
        return view;

    }

    private void getSliderDetails() {

        RetrofitInterface retrofitInterface = ServiceConfig.createService(RetrofitInterface.class);

        Call<SliderModel> call = retrofitInterface.getProductSlider();

        call.enqueue(new Callback<SliderModel>() {
            @Override
            public void onResponse(Call<SliderModel> call, Response<SliderModel> response) {

                if (response.isSuccessful()) {
                    slider = response.body();
                    List<SliderModel.Slideshow> product = slider.getSlideshow();

                    url_maps = new HashMap<>();

                    for (int i = 0; i < product.size(); i++) {
                        String imageName = product.get(i).getImage();
                        url_maps.put(product.get(i).getTitle(), imageName);
                    }

                    for (String name : url_maps.keySet()) {
                        TextSliderView textSliderView = new TextSliderView(getContext());
                        // initialize a SliderLayout
                        textSliderView
                                .description(name)
                                .image(url_maps.get(name))
                                .setScaleType(BaseSliderView.ScaleType.Fit);
                        mDemoSlider.addSlider(textSliderView);
                    }
                    mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Accordion);
                    mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
                    mDemoSlider.setCustomAnimation(new DescriptionAnimation());
                    mDemoSlider.setDuration(4000);

                } else {
                }

            }

            @Override
            public void onFailure(Call<SliderModel> call, Throwable t) {
                Toast.makeText(getContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
                t.printStackTrace();
            }
        });
    }
}
