package com.smartkirana.aims.aimsshop.views.activities.Cart

import com.smartkirana.aims.aimsshop.interfaces.BasePresenter
import com.smartkirana.aims.aimsshop.interfaces.BaseResponse
import com.smartkirana.aims.aimsshop.interfaces.BaseView
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel

internal interface ICart {
    interface View : BaseView {
        fun onSuccess(categoriesListModel: ProductListModel)
        fun showStub(show: Boolean)
        fun onFailure(message: String?)
    }

    interface Presenter : BasePresenter {
        fun getProductList()
    }


    interface Controller {
        fun getProductList(map: Map<String?, String?>?, listener: OnFinishListener?)
    }

    interface OnFinishListener : BaseResponse {
        fun onSuccess(categoriesListModel: ProductListModel)
        fun onFailure(message: String?)
        fun onNoData()
    }

}
