package com.smartkirana.aims.aimsshop.interfaces

interface BaseResponse : InternetConnection, UnKnownError {
}