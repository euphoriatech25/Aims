package com.smartkirana.aims.aimsshop.utils

class Constants {
    companion object {
        private const val API_TOKEN = "api_token"
        const val CONNECTION_TIME_OUT = 1000
        const val ROUTE = "route"
        const val CONTENT_TYPE = "Content-Type"
        const val ACCEPT = "Accept"
        const val JSON = "application/json"

        const val EMAIL = "email"
        const val PASSWORD = "password"
        const val CONFIRM = "confirm"
        const val FIRSTNAME = "firstname"
        const val LASTNAME = "lastname"
        const val TELEPHONE = "telephone"
        const val TERM = "term"

    }
}