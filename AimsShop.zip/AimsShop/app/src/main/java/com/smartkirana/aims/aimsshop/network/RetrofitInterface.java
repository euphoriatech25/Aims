package com.smartkirana.aims.aimsshop.network;

import com.smartkirana.aims.aimsshop.views.activities.Register.CreateAccountModel;
import com.smartkirana.aims.aimsshop.views.fragments.Categories.CategoriesModel;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.HomeFeaturedModel;
import com.smartkirana.aims.aimsshop.views.fragments.HomeSlider.SliderModel;
import com.smartkirana.aims.aimsshop.views.fragments.NavCategories.CategoriesListModel;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitInterface {

    @POST("index.php?route=api/register")
    Call<ResponseBody> createAccount(@Body CreateAccountModel createAccountModel);

    @GET("index.php?route=api/product")
    Call<ProductListModel> getProductList();

    @GET("index.php?route=api/featured")
    Call<HomeFeaturedModel> getFeaturedList();

    @GET("index.php?route=api/product")
    Call<CategoriesModel> getCategories();

    @GET("index.php?route=api/slideshow")
    Call<SliderModel> getProductSlider();

    @GET("index.php?route=api/menu")
    Call<CategoriesListModel> getCategoriesList();
}
