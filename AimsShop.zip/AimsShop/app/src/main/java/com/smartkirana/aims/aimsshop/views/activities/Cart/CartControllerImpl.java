package com.smartkirana.aims.aimsshop.views.activities.Cart;

import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel;

import org.jetbrains.annotations.Nullable;

import java.net.SocketTimeoutException;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartControllerImpl implements ICart.Controller {
    @Override
    public void getProductList(@Nullable Map<String, String> map, @Nullable ICart.OnFinishListener listener) {
        RetrofitInterface retrofitInterface = ServiceConfig.createService(RetrofitInterface.class);
        Call<ProductListModel> call = retrofitInterface.getProductList();

        call.enqueue(new Callback<ProductListModel>() {
            @Override
            public void onResponse(Call<ProductListModel> call, Response<ProductListModel> response) {

                if (response.isSuccessful()) {
                    if(response.body()!=null) {
                        ProductListModel productListModel = response.body();
                        listener.onSuccess(productListModel);
                    }else {
                        listener.onNoData();
                    }
                } else {
                    listener.unKnownError();
                }

            }

            @Override
            public void onFailure(Call<ProductListModel> call, Throwable t) {
                if (t instanceof SocketTimeoutException) {
                    listener.connectionTimeOut();
                } else {
                    listener.unKnownError();
                }
            }
        });
    }
}
