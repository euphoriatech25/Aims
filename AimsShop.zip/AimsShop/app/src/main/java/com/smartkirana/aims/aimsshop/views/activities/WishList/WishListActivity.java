package com.smartkirana.aims.aimsshop.views.activities.WishList;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.HomeFeaturedModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WishListActivity extends AppCompatActivity {
    WishListAdapter wishListAdapter;
    RecyclerView wishListRecycler;
    List<HomeFeaturedModel.Featured> wishListDetails;
    private GridLayoutManager layoutManager;
    HomeFeaturedModel homeFeaturedModel;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_wishlist);
        TextView toolbar = findViewById(R.id.tvToolbarTitle);
        toolbar.setText("My WishList");
        wishListRecycler=findViewById(R.id.wishlist_recycler_id);
        layoutManager = new GridLayoutManager(this, 1);
        wishListRecycler.setLayoutManager(layoutManager);
        wishListRecycler.setHasFixedSize(true);
        wishListRecycler.setFocusable(false);
        wishListRecycler.setAdapter(wishListAdapter);

        changeStatusBarColor();
        init();
    }

    private void changeStatusBarColor() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.account));

    }

    private void init() {
        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<HomeFeaturedModel> call = post.getFeaturedList();
        call.enqueue(new Callback<HomeFeaturedModel>() {
            @Override
            public void onResponse(Call<HomeFeaturedModel> call, Response<HomeFeaturedModel> response) {
                if (response.isSuccessful()) {

                    homeFeaturedModel = response.body();
                    wishListDetails = homeFeaturedModel.getFeatured();
                    wishListAdapter = new WishListAdapter(WishListActivity.this, wishListDetails);
                    wishListRecycler.setAdapter(wishListAdapter);
                }
            }

            @Override
            public void onFailure(Call<HomeFeaturedModel> call, Throwable t) {

            }
        });
    }


}
