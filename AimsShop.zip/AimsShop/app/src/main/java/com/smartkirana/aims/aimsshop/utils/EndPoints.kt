package com.smartkirana.aims.aimsshop.utils

class EndPoints {
    companion object {
//        const val BASE_URL ="http://www.aimsshop.net/";
        const val BASE_URL ="http://192.168.100.105:80/OpenCart/"
        const val API ="index.php?route=api/"


        const val PRODUCTLIST =API+"product";

    }
}