package com.smartkirana.aims.aimsshop.views.activities.Cart;

import com.smartkirana.aims.aimsshop.utils.Constants;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

public class CartPresenterImpl implements ICart.Presenter, ICart.OnFinishListener {
    private ICart.View view;
    private ICart.Controller controller;

    public CartPresenterImpl(ICart.View view, ICart.Controller controller) {
        this.view = view;
        this.controller = controller;
    }

    @Override
    public void getProductList() {
        if (view != null) {
//            if (AppUtils.isNetworkAvailable()) {
                view.showProgressBar(true);
                Map<String, String> map = new HashMap<>();
                map.put(Constants.CONTENT_TYPE,Constants.JSON );
                controller.getProductList(map, this);
//            } else {
//                view.noInternetConnection();
//            }
        }
    }



    @Override
    public void onFailure(@Nullable String message) {
        if (view != null) {
            view.showProgressBar(false);
            view.onFailure(message);
        }
    }

    @Override
    public void onNoData() {
        if (view != null) {
            view.showProgressBar(false);
            view.showStub(true);
        }
    }

    @Override
    public void noInternetConnection() {
        if (view != null) {
            view.showProgressBar(false);
            view.noInternetConnection();
        }
    }

    @Override
    public void connectionTimeOut() {
        if (view != null) {
            view.showProgressBar(false);
            view.connectionTimeOut();
        }
    }

    @Override
    public void unKnownError() {
        if (view != null) {
            view.showProgressBar(false);
            view.unKnownError();
        }
    }

    @Override
    public void onDestroy() {
        view = null;
    }

    @Override
    public void onSuccess(@NotNull ProductListModel categoriesListModel) {
        if (view != null) {
            view.showProgressBar(false);
            if (categoriesListModel.getProducts().size()!=0)
                view.onSuccess(categoriesListModel);
            else
                view.showStub(true);
        }
    }
}
