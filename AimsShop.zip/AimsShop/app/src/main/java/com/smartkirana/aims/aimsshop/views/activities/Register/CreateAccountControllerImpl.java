package com.smartkirana.aims.aimsshop.views.activities.Register;

import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;
import com.smartkirana.aims.aimsshop.views.activities.createAccount.ICreateAccount;

import org.jetbrains.annotations.NotNull;

import java.net.SocketTimeoutException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateAccountControllerImpl implements ICreateAccount.Controller {
    @Override
    public void createAccount(@NotNull CreateAccountModel model, @NotNull ICreateAccount.OnFinishListener listener) {
        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<ResponseBody> call = post.createAccount(model);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    listener.onSuccess();
                } else {
                    listener.unKnownError();
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if (t instanceof SocketTimeoutException) {
                    listener.connectionTimeOut();
                } else {
                    listener.unKnownError();
                }
            }
        });
    }
}