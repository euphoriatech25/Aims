package com.smartkirana.aims.aimsshop.views.activities.Home;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.views.activities.Cart.CartActivity;
import com.smartkirana.aims.aimsshop.views.activities.SearchActivity.SearchProductActivity;
import com.smartkirana.aims.aimsshop.views.activities.WishList.WishListActivity;
import com.smartkirana.aims.aimsshop.views.fragments.Account.AccountFragment;
import com.smartkirana.aims.aimsshop.views.fragments.Categories.CategoriesFragment;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.FeaturedListFragment;
import com.smartkirana.aims.aimsshop.views.fragments.Home.HomeFragment;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {

                case R.id.navigation_home:
                    FragmentManager manager1 = getSupportFragmentManager();
                    Fragment fragment1 = new HomeFragment();
                    FragmentTransaction transaction1 = manager1.beginTransaction();
                    transaction1.replace(R.id.container, fragment1).addToBackStack(null);
                    transaction1.commit();
                    return true;
                case R.id.navigation_dashboard:
                    FragmentManager manager2 = getSupportFragmentManager();
                    Fragment fragment = new CategoriesFragment();
                    FragmentTransaction transaction = manager2.beginTransaction();
                    transaction.replace(R.id.container, fragment).addToBackStack(null);
                    transaction.commit();
                    return true;
                case R.id.navigation_notifications:
                    FragmentManager manager3 = getSupportFragmentManager();
                    Fragment fragment3 = new FeaturedListFragment();
                    FragmentTransaction transaction3 = manager3.beginTransaction();
                    transaction3.replace(R.id.container, fragment3).addToBackStack(null);
                    transaction3.commit();
                    return true;
                case R.id.navigation_cart:
                    FragmentManager manager4 = getSupportFragmentManager();
                    Fragment fragment4 = new AccountFragment();
                    FragmentTransaction transaction4 = manager4.beginTransaction();
                    transaction4.replace(R.id.container, fragment4).addToBackStack(null);
                    transaction4.commit();
                    return true;
            }
            return false;
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_search) {
            startActivity(new Intent(HomeActivity.this, SearchProductActivity.class));
            finish();
            return true;
        }
        if (id == R.id.action_favorite) {
            startActivity(new Intent(HomeActivity.this, WishListActivity.class));
            finish();
            return true;
        } if (id == R.id.action_cart) {
            startActivity(new Intent(HomeActivity.this, CartActivity.class));
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        changeStatusBarColor();

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Aims Shop");
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view_side);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);


        FragmentManager manager1 = getSupportFragmentManager();
        Fragment fragment1 = new HomeFragment();
        FragmentTransaction transaction1 = manager1.beginTransaction();
        transaction1.replace(R.id.container, fragment1).addToBackStack(null);
        transaction1.commit();

    }

    private void changeStatusBarColor() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.account));

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
