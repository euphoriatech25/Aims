package com.smartkirana.aims.aimsshop.views.fragments.Home;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.FeaturedListFragment;
import com.smartkirana.aims.aimsshop.views.fragments.HomeSlider.SliderFragment;
import com.smartkirana.aims.aimsshop.views.fragments.NavCategories.CategoriesList;

public class HomeFragment extends Fragment{
    Button productSearchView;
    ImageView side_menu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.content_home, parent, false);

        FragmentManager manager2 = getChildFragmentManager();
        Fragment fragment2 = new SliderFragment();
        FragmentTransaction transaction2 = manager2.beginTransaction();
        transaction2.replace(R.id.containerSlider, fragment2).addToBackStack(null);
        transaction2.commit();

        FragmentManager manager3 = getChildFragmentManager();
        Fragment fragment3 = new CategoriesList();
        FragmentTransaction transaction3 = manager3.beginTransaction();
        transaction3.replace(R.id.categoriesList, fragment3).addToBackStack(null);
        transaction3.commit();

        FragmentManager manager4 = getChildFragmentManager();
        Fragment fragment4 = new FeaturedListFragment();
        FragmentTransaction transaction4 = manager4.beginTransaction();
        transaction4.replace(R.id.featureList, fragment4).addToBackStack(null);
        transaction4.commit();


        return view;
    }


}
