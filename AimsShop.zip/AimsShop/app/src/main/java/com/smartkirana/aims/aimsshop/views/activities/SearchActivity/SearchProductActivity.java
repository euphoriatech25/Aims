package com.smartkirana.aims.aimsshop.views.activities.SearchActivity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.FeaturedCategoriesAdapter;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.HomeFeaturedModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchProductActivity extends AppCompatActivity {
    private EditText etsearch;
    public ArrayList<HomeFeaturedModel.Featured> movieNamesArrayList;
    public ArrayList<HomeFeaturedModel.Featured> array_sort;
    int textlength = 0;
    private GridLayoutManager layoutManager;
    FeaturedCategoriesAdapter featuredCategoriesAdapter;
    RecyclerView searchRecycler;
    ImageButton btnSpeak;
    private static final int REQ_SCAN_RESULT = 200;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    private TextView heading;
    boolean searchInProgress = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_search);
        searchRecycler = findViewById(R.id.search_list_view);
        heading = findViewById(R.id.txtSpeech_heading);
        layoutManager = new GridLayoutManager(SearchProductActivity.this, 2);
        searchRecycler.setLayoutManager(layoutManager);
        searchRecycler.setHasFixedSize(true);
        searchRecycler.setFocusable(false);
        searchRecycler.setAdapter(featuredCategoriesAdapter);

        btnSpeak = findViewById(R.id.btnSpeak);

        btnSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptSpeechInput();
            }
        });
        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<HomeFeaturedModel> call = post.getFeaturedList();
        call.enqueue(new Callback<HomeFeaturedModel>() {
            @Override
            public void onResponse(Call<HomeFeaturedModel> call, Response<HomeFeaturedModel> response) {
                if (response.isSuccessful()) {
                    HomeFeaturedModel featuredModel = response.body();
                    List<HomeFeaturedModel.Featured> featured = featuredModel.getFeatured();
                    movieNamesArrayList = new ArrayList<>();
                    array_sort = new ArrayList<>();

                    for (int i = 0; i < featured.size(); i++) {
                        HomeFeaturedModel.Featured featuredList = new HomeFeaturedModel.Featured(featured.get(i).getThumb(), featured.get(i).getName(), featured.get(i).getPrice(), featured.get(i).getSpecial());

                        movieNamesArrayList.add(featuredList);
                        array_sort.add(featuredList);
                    }
                }
            }

            @Override
            public void onFailure(Call<HomeFeaturedModel> call, Throwable t) {

            }
        });
        etsearch = findViewById(R.id.edt_search_input);
        etsearch.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                textlength = etsearch.getText().length();
                array_sort.clear();
                for (int i = 0; i < movieNamesArrayList.size(); i++) {
                    if (textlength <= movieNamesArrayList.get(i).getName().length()) {
                        if (movieNamesArrayList.get(i).getName().toLowerCase().trim().contains(
                                etsearch.getText().toString().toLowerCase().trim())) {
                            array_sort.add(movieNamesArrayList.get(i));
                        }
                    }
                }

                featuredCategoriesAdapter = new FeaturedCategoriesAdapter(SearchProductActivity.this, array_sort);
                searchRecycler.setAdapter(featuredCategoriesAdapter);

            }
        });

    }

    private void promptSpeechInput() {
        searchInProgress = true;
        array_sort.clear();

        heading.setText("Search Products");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What do you wish for");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(this,
                    "Voice search not supported by your device ",
                    Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        searchInProgress = false;

        if (resultCode == this.RESULT_OK && null != data) {
            switch (requestCode) {
                case REQ_CODE_SPEECH_INPUT: {

                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    textlength = result.get(0).length();
                    heading.setText("Showing Results for " + result.get(0));

                    for (int i = 0; i < movieNamesArrayList.size(); i++) {
                        if (textlength <= movieNamesArrayList.get(i).getName().length()) {
                            if (movieNamesArrayList.get(i).getName().toLowerCase().trim().contains(
                                    etsearch.getText().toString().toLowerCase().trim())) {
                                array_sort.add(movieNamesArrayList.get(i));
                            }
                        }
                    }

                    featuredCategoriesAdapter = new FeaturedCategoriesAdapter(this, array_sort);
                    searchRecycler.setAdapter(featuredCategoriesAdapter);

                    break;
                }

                case REQ_SCAN_RESULT:
                    // String contents = data.getStringExtra("SCAN_RESULT");
                    // String format = data.getStringExtra("SCAN_RESULT_FORMAT");
                    // Toast.makeText(getActivity(), "Scan Success", 1000).show();
                    break;

            }

        }

    }

}