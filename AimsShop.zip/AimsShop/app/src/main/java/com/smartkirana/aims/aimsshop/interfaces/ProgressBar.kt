package com.smartkirana.aims.aimsshop.interfaces

interface ProgressBar {
    fun showProgressBar(showpBar: Boolean)
}