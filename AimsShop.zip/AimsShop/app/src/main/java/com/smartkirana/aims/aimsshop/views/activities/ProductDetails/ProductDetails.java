package com.smartkirana.aims.aimsshop.views.activities.ProductDetails;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.utils.AppUtils;
import com.smartkirana.aims.aimsshop.views.activities.Cart.CartControllerImpl;
import com.smartkirana.aims.aimsshop.views.activities.Cart.CartPresenterImpl;
import com.smartkirana.aims.aimsshop.views.activities.Cart.ICart;
import com.smartkirana.aims.aimsshop.views.activities.base.BaseActivity;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ProductDetails extends BaseActivity implements ICart.View {
    ProgressBar progressBar;
    ConstraintLayout containerProductDetails;
    String product_name;
    private CartPresenterImpl presenter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_product_details);
        containerProductDetails = findViewById(R.id.containerProductDetails);
        progressBar = findViewById(R.id.progressBar);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.account));
        Intent data = getIntent();
        if (data != null) {
            product_name = data.getStringExtra("Product_Name");
        }
        setUpToolbar(product_name, true);
        init();
    }
    private void init() {


        presenter = new CartPresenterImpl(this, new CartControllerImpl());
        getStartIntent();
    }

    private void getStartIntent() {
        AppUtils.freezeUi(this, true);
        presenter.getProductList();

    }
    @Override
    public void onSuccess(@NotNull ProductListModel categoriesListModel) {
        Toast.makeText(this, categoriesListModel.getProducts().get(0).getName(), Toast.LENGTH_SHORT).show();
        AppUtils.freezeUi(this, false);
            View view = LayoutInflater.from(this).inflate(R.layout.layout_product_details, containerProductDetails, false);

            ImageView product_image = view.findViewById(R.id.product_image);
            TextView product_name = view.findViewById(R.id.product_name);
            TextView product_unit_price = view.findViewById(R.id.product_actual_price);
            TextView product_total_price = view.findViewById(R.id.product_description);
            product_name.setText(categoriesListModel.getProducts().get(0).getName());
            product_unit_price.setText(categoriesListModel.getProducts().get(0).getPrice());
            product_total_price.setText(categoriesListModel.getProducts().get(0).getDescription());
            Glide.with(this).load(categoriesListModel.getProducts().get(0).getThumb()).into(product_image);
            containerProductDetails.addView(view);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(ProductDetails.this, "there there", Toast.LENGTH_SHORT).show();
                }
            });
        }

    @Override
    public void showStub(boolean show) {
        if (show) {
            Toast.makeText(this, "No Product Added Yet", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onFailure(@Nullable String message) {
        AppUtils.showToast(this, message);
    }

    @Override
    public void showProgressBar(boolean showpBar) {
        AppUtils.showProgressBar(showpBar, progressBar);
    }
}