package com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct;

public class FeaturedControllerImpl {
}
