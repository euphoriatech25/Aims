package com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct

interface IFeature {
}