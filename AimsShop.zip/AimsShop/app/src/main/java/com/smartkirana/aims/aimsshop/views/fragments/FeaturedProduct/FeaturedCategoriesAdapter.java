package com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;

import java.util.List;

public class FeaturedCategoriesAdapter extends RecyclerView.Adapter<FeaturedCategoriesAdapter.RecyclerViewCartHolder> {
    Context context;
    List<HomeFeaturedModel.Featured> featureds;
    RetrofitInterface retrofitInterface;


    private FeaturedCategoriesAdapter.OnItemClickListener mListener;

    public interface OnItemClickListener {
        void onItemClick(int position, View itemView);
    }

    public void setOnItemClickListener(FeaturedCategoriesAdapter.OnItemClickListener listener) {
        mListener = listener;
    }


    public FeaturedCategoriesAdapter(Context context, List<HomeFeaturedModel.Featured> featureds) {
        this.context = context;
        this.featureds = featureds;
    }

    @NonNull
    @Override
    public FeaturedCategoriesAdapter.RecyclerViewCartHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.product_layout, viewGroup, false);
        return new RecyclerViewCartHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FeaturedCategoriesAdapter.RecyclerViewCartHolder holder, int position) {
        holder.product_name.setText(featureds.get(position).getName());
          Glide.with(context).load(featureds.get(position).getThumb()).into(holder.product_image);
        holder.wishlist_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                holder.wishlist_fav.setColorFilter(Color.parseColor("#FD0505"));
            }
        });

        String special = featureds.get(position).getSpecial();
        if (special.equalsIgnoreCase("false")) {
            holder.product_unit_price.setText(featureds.get(position).getPrice());

        } else {
            holder.product_unit_price.setText(featureds.get(position).getSpecial());

            holder.product_total_price.setText(featureds.get(position).getPrice());
            holder.product_total_price.setPaintFlags(holder.product_total_price.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        }
    }

    @Override
    public int getItemCount() {
        return featureds.size();
    }

    class RecyclerViewCartHolder extends RecyclerView.ViewHolder {
        ImageView product_image, wishlist_fav;
        TextView product_name, product_unit_price, product_total_price;

        public RecyclerViewCartHolder(@NonNull View itemView) {
            super(itemView);

            product_image = itemView.findViewById(R.id.home_product_id);
            product_name = itemView.findViewById(R.id.product_name);
            product_unit_price = itemView.findViewById(R.id.product_actual_price);
            product_total_price = itemView.findViewById(R.id.product_special_price);
            wishlist_fav = itemView.findViewById(R.id.favorite);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (mListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            mListener.onItemClick(position, view);
                        }
                    }
                }
            });

        }
    }
}
