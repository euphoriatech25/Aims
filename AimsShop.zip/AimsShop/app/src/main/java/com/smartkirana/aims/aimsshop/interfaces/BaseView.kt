package com.smartkirana.aims.aimsshop.interfaces


interface BaseView : ProgressBar, InternetConnection, UnKnownError {
}