package com.smartkirana.aims.aimsshop.views.fragments.Account;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.views.activities.OnlinePayment.CellPayActivity;
import com.smartkirana.aims.aimsshop.views.activities.Register.CreateAccountActivity;

public class AccountFragment extends Fragment {
CardView signin_signon;
TextView payment_method;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_account, parent, false);
        signin_signon=view.findViewById(R.id.signin_signon);
        payment_method=view.findViewById(R.id.payment_method);
        payment_method.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), CellPayActivity.class));
            }
        });
        signin_signon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), CreateAccountActivity.class));
            }
        });
        return view;
    }

}
