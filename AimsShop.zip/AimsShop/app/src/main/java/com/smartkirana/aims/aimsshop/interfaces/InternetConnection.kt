package com.smartkirana.aims.aimsshop.interfaces

interface InternetConnection {
    fun noInternetConnection()
    fun connectionTimeOut()

}