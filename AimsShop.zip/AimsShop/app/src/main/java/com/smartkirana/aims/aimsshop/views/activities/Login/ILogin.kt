package com.workerswallet.views.activities.login

internal interface ILogin {

}
