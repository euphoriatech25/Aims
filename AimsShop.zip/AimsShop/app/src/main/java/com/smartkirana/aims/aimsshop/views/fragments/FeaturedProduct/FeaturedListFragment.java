package com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.IProductList;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListPresenterImpl;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FeaturedListFragment extends Fragment implements IProductList.View {

    RecyclerView productRecycle;
    FeaturedCategoriesAdapter featuredCategoriesAdapter;
    HomeFeaturedModel featuredModel;
    List<HomeFeaturedModel.Featured> featuredList;
    private ProductListPresenterImpl presenter;
    private GridLayoutManager layoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_list, parent, false);
        productRecycle = view.findViewById(R.id.product_recycler_id);
        layoutManager = new GridLayoutManager(getContext(), 2);
        productRecycle.setLayoutManager(layoutManager);
        productRecycle.setHasFixedSize(true);
        productRecycle.setFocusable(false);
        productRecycle.setAdapter(featuredCategoriesAdapter);


        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<HomeFeaturedModel> call = post.getFeaturedList();
        call.enqueue(new Callback<HomeFeaturedModel>() {
            @Override
            public void onResponse(Call<HomeFeaturedModel> call, Response<HomeFeaturedModel> response) {
                if (response.isSuccessful()) {

                    featuredModel = response.body();
                    featuredList = featuredModel.getFeatured();
                    featuredCategoriesAdapter = new FeaturedCategoriesAdapter(getContext(), featuredList);
                    productRecycle.setAdapter(featuredCategoriesAdapter);

                } else {
                }
            }

            @Override
            public void onFailure(Call<HomeFeaturedModel> call, Throwable t) {
            }
        });
        return view;

    }



    @Override
    public void noInternetConnection() {

    }

    @Override
    public void connectionTimeOut() {

    }

    @Override
    public void showProgressBar(boolean showpBar) {

    }

    @Override
    public void unKnownError() {

    }

    @NotNull
    @Override
    public String setProductId() {
        return null;
    }

    @NotNull
    @Override
    public String setThumb() {
        return null;
    }

    @NotNull
    @Override
    public String setName() {
        return null;
    }

    @NotNull
    @Override
    public String setDescription() {
        return null;
    }

    @NotNull
    @Override
    public String setPrice() {
        return null;
    }

    @NotNull
    @Override
    public String setSpecial() {
        return null;
    }

    @NotNull
    @Override
    public String setTax() {
        return null;
    }

    @NotNull
    @Override
    public String setMinimum() {
        return null;
    }

    @NotNull
    @Override
    public String setRating() {
        return null;
    }

    @NotNull
    @Override
    public String setHref() {
        return null;
    }


}
