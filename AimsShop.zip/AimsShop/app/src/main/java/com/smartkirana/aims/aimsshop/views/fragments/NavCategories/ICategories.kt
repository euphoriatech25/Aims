package com.smartkirana.aims.aimsshop.views.fragments.NavCategories

interface ICategories {
}