package com.smartkirana.aims.aimsshop.views.fragments.NavCategories;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoriesList extends Fragment implements CategoriesListAdapter.OnItemClickListener {
    RecyclerView categoriesRecycle;
    CategoriesListAdapter categoriesAdapter;
    CategoriesListModel categoriesListModel;
    private LinearLayoutManager layoutManager;
    List<CategoriesListModel.Category> categoryList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_categories_list, parent, false);
        categoriesRecycle=view.findViewById(R.id.recyclerview);
        layoutManager = new LinearLayoutManager(
                getContext(),
                LinearLayoutManager.HORIZONTAL,
                false);
        categoriesRecycle.setLayoutManager(layoutManager);
        categoriesRecycle.setHasFixedSize(true);
        categoriesRecycle.setFocusable(false);
        categoriesRecycle.setAdapter(categoriesAdapter);
        init();
        return view;

    }

    private void init() {
        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<CategoriesListModel> call = post.getCategoriesList();
        call.enqueue(new Callback<CategoriesListModel>() {
            @Override
            public void onResponse(Call<CategoriesListModel> call, Response<CategoriesListModel> response) {
                if(response.isSuccessful()){
                    categoriesListModel=response.body();
                    categoryList=categoriesListModel.getCategories();
                    categoriesAdapter = new CategoriesListAdapter(getContext(), categoryList);
                    categoriesRecycle.setAdapter(categoriesAdapter);
                }else {
                    Toast.makeText(getContext(), "categories r nottt here", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<CategoriesListModel> call, Throwable t) {

            }
        });
    }

    @Override
    public void onItemClick(int position, View itemView) {

    }
}
