package com.smartkirana.aims.aimsshop.views.activities.Login;

public class LoginPresenterImpl {}
