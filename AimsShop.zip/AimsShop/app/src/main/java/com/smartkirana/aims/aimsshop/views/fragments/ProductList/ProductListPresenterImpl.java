package com.smartkirana.aims.aimsshop.views.fragments.ProductList;

import android.util.Log;

import com.smartkirana.aims.aimsshop.utils.Constants;
import com.smartkirana.aims.aimsshop.utils.EndPoints;
import com.smartkirana.aims.aimsshop.views.fragments.FeaturedProduct.FeaturedListFragment;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;

public class ProductListPresenterImpl implements IProductList.Presenter, IProductList.OnFinishListener {
    private static final String TAG = "FeaturedListFragment";
    private IProductList.View view;
    private IProductList.Controller controller;
    public ProductListPresenterImpl(FeaturedListFragment productList, ProductListControllerImpl productListController) {
        this.view = view;
        this.controller = controller;
    }

    @Override
    public void getProductList() {
        if (view != null) {
            view.showProgressBar(true);
            Map<String, String> map = new HashMap<>();
            map.put(Constants.ROUTE, EndPoints.PRODUCTLIST);

            Log.d(TAG, "getDocumentDetail:"+map.toString());
            controller.getProductList(map, this);
        }
    }

    @Override
    public void onSuccess(@NotNull ProductListModel body) {
        if (view != null) {
            Log.d(TAG, "onSuccess: "+body.toString());

//            view.showProgressBar(false);
//            view.setProductId(body.get());
//            view.setBackImage(body.getBackImage());
//            view.setCreatedDate(body.getCreatedDate());
//            view.setSupplierName(body.getSupplierName());
//            view.setFileTitle(body.getFileTitle());
//            view.setFileType(body.getFileType());
//            view.setDateOfIssue(body.getDateOfIssue());
//            view.setDateOfExpire(body.getDateOfExpire());
//            view.setFileDescription(body.getFileDescription());
//            view.setExtraTrainingType(body.getExtraTrainingType());
        }
    }

    @Override
    public void onDestroy() {
        view = null;
    }

    @Override
    public void noInternetConnection() {
        if (view != null) {
            view.showProgressBar(false);
            view.noInternetConnection();
        }
    }

    @Override
    public void connectionTimeOut() {
        if (view != null) {
            view.showProgressBar(false);
            view.connectionTimeOut();
        }
    }

    @Override
    public void unKnownError() {
        if (view != null) {
            view.showProgressBar(false);
            view.unKnownError();
        }
    }
}
