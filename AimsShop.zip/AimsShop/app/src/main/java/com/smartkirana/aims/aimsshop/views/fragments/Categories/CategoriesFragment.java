package com.smartkirana.aims.aimsshop.views.fragments.Categories;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.network.RetrofitInterface;
import com.smartkirana.aims.aimsshop.network.ServiceConfig;

import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListPresenterImpl;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CategoriesFragment extends Fragment {
    RecyclerView productRecycle;
    CategoriesAdapter featuredCategoriesAdapter;
    CategoriesModel featuredModel;
    List<CategoriesModel.Product> featuredList;
    private ProductListPresenterImpl presenter;
    private GridLayoutManager layoutManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product_list, parent, false);
        productRecycle = view.findViewById(R.id.product_recycler_id);
        layoutManager = new GridLayoutManager(getContext(), 2);
        productRecycle.setLayoutManager(layoutManager);
        productRecycle.setHasFixedSize(true);
        productRecycle.setFocusable(false);
        productRecycle.setAdapter(featuredCategoriesAdapter);
        init();
        return view;

    }

    private void init() {
        RetrofitInterface post = ServiceConfig.createService(RetrofitInterface.class);
        Call<CategoriesModel> call = post.getCategories();
        call.enqueue(new Callback<CategoriesModel>() {
            @Override
            public void onResponse(Call<CategoriesModel> call, Response<CategoriesModel> response) {
                if (response.isSuccessful()) {

                    featuredModel = response.body();
                    featuredList = featuredModel.getProducts();
                    featuredCategoriesAdapter = new CategoriesAdapter(getContext(), featuredList);
                    productRecycle.setAdapter(featuredCategoriesAdapter);
                }
            }

            @Override
            public void onFailure(Call<CategoriesModel> call, Throwable t) {

            }
        });
    }

}
