package com.smartkirana.aims.aimsshop.interfaces

interface UnKnownError {
    fun unKnownError()

}