package com.smartkirana.aims.aimsshop.views.activities.Cart;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.smartkirana.aims.aimsshop.R;
import com.smartkirana.aims.aimsshop.utils.AppUtils;
import com.smartkirana.aims.aimsshop.views.activities.ProductDetails.ProductDetails;
import com.smartkirana.aims.aimsshop.views.activities.base.BaseActivity;
import com.smartkirana.aims.aimsshop.views.fragments.ProductList.ProductListModel;

public class CartActivity extends BaseActivity implements ICart.View {
    LinearLayout linearLayout;
    ProgressBar progressBar;
    String name;
    private CartPresenterImpl presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        progressBar = findViewById(R.id.progressBar);
        linearLayout = findViewById(R.id.linearLayout);
        init();
    }

    private void init() {

        changeStatusBarColor();
        setUpToolbar("My Shopping Cart", true);
        presenter = new CartPresenterImpl(this, new CartControllerImpl());
        getStartIntent();
    }

    private void getStartIntent() {
        AppUtils.freezeUi(this, true);
        presenter.getProductList();

    }

    private void changeStatusBarColor() {
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(getResources().getColor(R.color.account));

    }

    @Override
    public void onSuccess(final ProductListModel productListModel) {
        AppUtils.freezeUi(this, false);
        for (int i = 0; i < productListModel.getProducts().size(); i++) {
            View view = LayoutInflater.from(this).inflate(R.layout.cart_items, linearLayout, false);
            name = productListModel.getProducts().get(i).getName();
            ImageView product_image = view.findViewById(R.id.product_image);
            TextView product_name = view.findViewById(R.id.product_name);
            TextView product_unit_price = view.findViewById(R.id.product_unit_price);
            TextView product_total_price = view.findViewById(R.id.product_total_price);
            product_name.setText(productListModel.getProducts().get(i).getName());
            product_unit_price.setText(productListModel.getProducts().get(i).getPrice());
            product_total_price.setText(productListModel.getProducts().get(i).getPrice());
            Glide.with(this).load(productListModel.getProducts().get(i).getThumb()).into(product_image);
            linearLayout.addView(view);

            String name = productListModel.getProducts().get(i).getName();
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(CartActivity.this, ProductDetails.class);
                    intent.putExtra("Product_Name",name);
                    startActivity(intent);
                    finish();
//                    Toast.makeText(CartActivity.this,name , Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void showProgressBar(boolean showpBar) {
        AppUtils.showProgressBar(showpBar, progressBar);
    }

    @Override
    public void showStub(boolean show) {
        if (show) {
            Toast.makeText(this, "No Product Added Yet", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onFailure(@org.jetbrains.annotations.Nullable String message) {
        AppUtils.showToast(this, message);
    }

    @Override
    protected void onDestroy() {
        presenter.onDestroy();
        super.onDestroy();
    }
}
